<section class="banner">
	<section class="logo">
		<img src="<?php echo base_url(); ?>images/coat_of_arms-resized.png" />

	</section>
	<section class="credentials">
		<section class="title">
			Ministry Of Public Health and Sanitation
		</section>
		<section class="subtitle">
			Department of Family Health<p></p>
		</section>
		<section class="division">
			Division of Nutrition<p></p><p></p>
		</section>
	</section>
	<section class="date">
		<?php echo date("l, F d Y"); ?>
	</section>
</section>