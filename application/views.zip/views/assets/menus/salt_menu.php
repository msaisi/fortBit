<?php $accessLevel = $this -> session -> userdata('userRights'); ?>
<li>
						<a href="#" class="dropdown-toggle">
							<i class="icon-edit"></i>
							<span class="menu-text"> Salt </span>

							<b class="arrow icon-angle-down"></b>
						</a>

						<ul class="submenu">
						<?php if($accessLevel==2){?>
			<li>
			<a id="internalFort_A1_li" class="salt-url"><i class="icon-double-angle-right"></i>Fortified Salt-Table A-1</a>
			</li>
			<li>
			<a id="externalFort_B1_li" class="salt-url"><i class="icon-double-angle-right"></i>Fortified Salt - Audits and Inspection - Table B-1</a>
			</li>
			<li>
			<a id="externalFort_B2_li" class="salt-url"><i class="icon-double-angle-right"></i>Fortified Salt - Audits and Inspection - Table B-2</a>
			</li>
			<li>
			<a id="externalFort_B3_li" class="salt-url"><i class="icon-double-angle-right"></i>Fortified Salt - Audits and Inspection - Table B-3</a>
			</li>
			<li>
			<a id="externalIod_B1_li" class="salt-url"><i class="icon-double-angle-right"></i>Iodized Salt - Audits and Inspection - Table B-1</a>
			</li>
			<?php }else if($accessLevel==3 || $accessLevel==4){ ?>
			<li>
				<a id = "internalFort_A2_li" class="salt-url"><i class="icon-double-angle-right"></i>Fortified Salt QC/QA -Table A-2</a>

			</li>
			<li>
			<a id="internalFort_B1_li" class="salt-url"><i class="icon-double-angle-right"></i>Fortified Salt QC/QA -Table B-1</a>
			</li>
			<li>
			<a id="internalFort_B2_li" class="salt-url"><i class="icon-double-angle-right"></i>Salt Fortification: Table B-2</a>
			</li>
			<li>
			<a id="internalFort_C1_li" class="salt-url"><i class="icon-double-angle-right"></i>Fortified Salt QC/QA -Table C-1</a>
			</li>
			<li>
			<a id="smallScale_A1_li" class="salt-url"><i class="icon-double-angle-right"></i>Fortified Salt - QA In Small Scale Operations - Table A-1</a>
			</li>
			<li>
			<a id="smallScale_A2_li" class="salt-url"><i class="icon-double-angle-right"></i>Fortified Salt - QA In Small Scale Operations - Table A-2</a>
			</li>
			<?php } ?>
            </ul>
</li>