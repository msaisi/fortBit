<?php
$this->load->view('menus/oil_menus');
$this->load->view('menus/sugar_menus');	
$this->load->view('menus/maize_menus');	
$this->load->view('menus/wheat_menus');	
$this->load->view('menus/salt_menus');	
?>