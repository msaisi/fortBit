<?php $accessLevel = $this -> session -> userdata('userRights'); ?>
<li>
						<a href="#" class="dropdown-toggle">
							<i class="icon-edit"></i>
							<span class="menu-text"> Maize </span>

							<b class="arrow icon-angle-down"></b>
						</a>

						<ul class="submenu">
						<li>
				<a id="internalMaizeFlour_A1_li" class="maize-url"><i class="icon-double-angle-right"></i>Internal Fortified Maize-Table A-1</a>
			</li>
			<li>
				<a id="internalMaizeFlour_A2_li" class="maize-url"><i class="icon-double-angle-right"></i>Internal Fortified Maize-Table A-2</a>
			</li>
			<li>
				<a id="internalMaizeFlour_B1_li" class="maize-url"><i class="icon-double-angle-right"></i>Internal Fortified Maize-Table B-1</a>
			</li>
			<li>
				<a id="internalMaizeFlour_B2_li" class="maize-url"><i class="icon-double-angle-right"></i>Internal Fortified Maize-Table B-2</a>
			</li>
			<li>
				<a id="internalMaizeFlour_C1_li" class="maize-url"><i class="icon-double-angle-right"></i>Internal Fortified Maize-Table C-1</a>
			</li>
			<li>
				<a id="externalMaizeFlour_B1_li" class="maize-url"><i class="icon-double-angle-right"></i>External Fortified Maize-Table B-1</a>
			<li>
				<a id="externalMaizeFlour_B2_li" class="maize-url"><i class="icon-double-angle-right"></i>External Fortified Maize-Table B-2</a>
			</li>
			<li>
				<a id="externalMaizeFlour_B3_li" class="maize-url"><i class="icon-double-angle-right"></i>External Fortified Maize-Table B-3</a>
			</li>
            </ul>
			</li>