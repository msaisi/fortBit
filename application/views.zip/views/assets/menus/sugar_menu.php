<?php $accessLevel = $this -> session -> userdata('userRights'); ?>
<li>
						<a href="#" class="dropdown-toggle">
							<i class="icon-edit"></i>
							<span class="menu-text"> Sugar </span>

							<b class="arrow icon-angle-down"></b>
						</a>

						<ul class="submenu">
							
                            <li>
				<a id="internalSugar_A1_li" class="sugar-url"><i class="icon-double-angle-right"></i>Internal Fortified Sugar-Table A-1</a>
			</li>
			<li>
				<a id="internalSugar_A2_li" class="sugar-url"><i class="icon-double-angle-right"></i>Internal Fortified Sugar-Table A-2</a>
			</li>
			<li>
				<a id="internalSugar_A3_li" class="sugar-url"><i class="icon-double-angle-right"></i>Internal Fortified Sugar-Table A-3</a>
			</li>
			<li>
				<a id="internalSugar_B1_li" class="sugar-url"><i class="icon-double-angle-right"></i>Internal Fortified Sugar-Table B-1</a>
			</li>
			<li>
				<a id="internalSugar_C1_li" class="sugar-url"><i class="icon-double-angle-right"></i>Internal Fortified Sugar-Table C-1</a>
			</li>
			<li>
				<a id="internalSugar_C2_li" class="sugar-url"><i class="icon-double-angle-right"></i>Internal Fortified Sugar-Table C-2</a>
			</li>
			<li>
				<a id="internalSugar_C3_li" class="sugar-url"><i class="icon-double-angle-right"></i>Internal Fortified Sugar-Table C-3</a>
			</li>
			<li>
				<a id="internalSugar_D1_li" class="sugar-url"><i class="icon-double-angle-right"></i>Internal Fortified Sugar-Table D-1</a>
			</li>
			<li>
				<a id="externalSugar_B1_li" class="sugar-url"><i class="icon-double-angle-right"></i>External Fortified Sugar-Table B-1</a>
			</li>
			<li>
				<a id="externalSugar_B2_li" class="sugar-url"><i class="icon-double-angle-right"></i>External Fortified Sugar-Table B-2</a>
			</li>
			<li>
				<a id="externalSugar_B3_li" class="sugar-url"><i class="icon-double-angle-right"></i>External Fortified Sugar-Table B-3</a>
			</li>
			<li>
				<a id="qualityAssurance_A1_li" class="sugar-url"><i class="icon-double-angle-right"></i>Quality Assurance-Table A-1</a>
			</li>
			<li>
				<a id="qualityAssurance_B1_li" class="sugar-url"><i class="icon-double-angle-right"></i>Quality Assurance-Table B-1</a>
			</li>
			<li>
				<a id="qualityAssurance_B2_li" class="sugar-url"><i class="icon-double-angle-right"></i>Quality Assurance-Table B-2</a>
			</li>
			<li>
				<a id="qualityAssurance_C1_li" class="sugar-url"><i class="icon-double-angle-right"></i>Quality Assurance-Table C-1</a>
			</li>
            </ul>
	</li>