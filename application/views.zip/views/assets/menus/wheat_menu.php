<?php $accessLevel = $this -> session -> userdata('userRights'); ?>
 <li>
						<a href="#" class="dropdown-toggle">
							<i class="icon-edit"></i>
							<span class="menu-text"> Wheat </span>

							<b class="arrow icon-angle-down"></b>
						</a>

						<ul class="submenu">
						 <li>
				<a id="internalWheatFlour_A1_li" class="wheat-url"><i class="icon-double-angle-right"></i>Internal Fortified Wheat-Table A-1</a>
			</li>
			<li>
				<a id="internalWheatFlour_A2_li" class="wheat-url"><i class="icon-double-angle-right"></i>Internal Fortified Wheat-Table A-2</a>
			</li>
			<li>
				<a id="internalWheatFlour_B1_li" class="wheat-url"><i class="icon-double-angle-right"></i>Internal Fortified Wheat-Table B-1</a>
			</li>
			<li>
				<a id="internalWheatFlour_B2_li" class="wheat-url"><i class="icon-double-angle-right"></i>Internal Fortified Wheat-Table B-2</a>
			</li>
			<li>
				<a id="internalWheatFlour_C1_li" class="wheat-url"><i class="icon-double-angle-right"></i>Internal Fortified Wheat-Table C-1</a>
			</li>
			<li>
				<a id="externalWheatFlour_B1_li" class="wheat-url"><i class="icon-double-angle-right"></i>External Fortified Wheat-Table B-1</a>
			</li>
			<li>
				<a id="externalWheatFlour_B2_li" class="wheat-url"><i class="icon-double-angle-right"></i>External Fortified Wheat-Table B-2</a>
			</li>
			<li>
				<a id="externalWheatFlour_B3_li" class="wheat-url"><i class="icon-double-angle-right"></i>External Fortified Wheat-Table B-3</a>
			</li>
            </ul>
			</li> 