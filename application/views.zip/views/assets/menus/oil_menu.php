<?php $accessLevel = $this -> session -> userdata('userRights'); ?>
<li>
						<a href="#" class="dropdown-toggle">
							<i class="icon-edit"></i>
							<span class="menu-text"> Oil </span>

							<b class="arrow icon-angle-down"></b>
						</a>

						<ul class="submenu">
							                           
                            
            <li>
				<a id="fortifiedOil_A1_li" class="oil-url"><i class="icon-double-angle-right"></i>Fortified Oil-Table A-1</a>
			</li>
			<li>
				<a id="fortifiedOil_B1_li" class="oil-url"><i class="icon-double-angle-right"></i>Fortified Oil-Table B-1</a>
			</li>
			<li>
				<a id="fortifiedOil_B2_li" class="oil-url"><i class="icon-double-angle-right"></i>Fortified Oil-Table B-2</a>
			</li>
			<li>
				<a id="fortifiedOil_C1_li" class="oil-url"><i class="icon-double-angle-right"></i>Fortified Oil-Table C-1</a>
			</li>         
						</ul>
					</li>